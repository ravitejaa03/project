package com.tasy_food.orders.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.mockito.Mockito.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.tasy_food.orders.enums.PaymentModes;
import com.tasy_food.orders.model.PaymentDetails;
import com.tasy_food.orders.repository.PaymentDetailsRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

@ContextConfiguration(classes = {PaymentService.class})
@ExtendWith(SpringExtension.class)
class PaymentServiceTest {
    @MockBean
    private PaymentDetailsRepository paymentDetailsRepository;

    @Autowired
    private PaymentService paymentService;

    @Test
    void testUpdatePayment() {
        PaymentDetails paymentDetails = new PaymentDetails();
        paymentDetails.setAddress("42 Main St");
        paymentDetails.setId(1);
        paymentDetails.setPaymentMode(PaymentModes.COD);
        when(this.paymentDetailsRepository.save((PaymentDetails) any())).thenReturn(paymentDetails);

        PaymentDetails paymentDetails1 = new PaymentDetails();
        paymentDetails1.setAddress("42 Main St");
        paymentDetails1.setId(1);
        paymentDetails1.setPaymentMode(PaymentModes.COD);
        this.paymentService.updatePayment(paymentDetails1);
        verify(this.paymentDetailsRepository).save((PaymentDetails) any());
        assertEquals("42 Main St", paymentDetails1.getAddress());
        assertEquals(PaymentModes.COD, paymentDetails1.getPaymentMode());
        assertEquals(1, paymentDetails1.getId().intValue());
    }


    @Test
    void testUpdatePayment2() {
        PaymentDetails paymentDetails = new PaymentDetails();
        paymentDetails.setAddress("42 Main St");
        paymentDetails.setId(1);
        paymentDetails.setPaymentMode(PaymentModes.COD);
        when(this.paymentDetailsRepository.save((PaymentDetails) any())).thenReturn(paymentDetails);

        PaymentDetails paymentDetails1 = new PaymentDetails();
        paymentDetails1.setAddress("42 Main St");
        paymentDetails1.setId(1);
        paymentDetails1.setPaymentMode(PaymentModes.COD);
        this.paymentService.updatePayment(paymentDetails1);
        verify(this.paymentDetailsRepository).save((PaymentDetails) any());
        assertEquals("42 Main St", paymentDetails1.getAddress());
        assertEquals(PaymentModes.COD, paymentDetails1.getPaymentMode());
        assertEquals(1, paymentDetails1.getId().intValue());
    }

    @Test
    void testInitiatePayment() {
        PaymentDetails paymentDetails = new PaymentDetails();
        paymentDetails.setAddress("42 Main St");
        paymentDetails.setId(1);
        paymentDetails.setPaymentMode(PaymentModes.COD);
        when(this.paymentDetailsRepository.save((PaymentDetails) any())).thenReturn(paymentDetails);

        PaymentDetails paymentDetails1 = new PaymentDetails();
        paymentDetails1.setAddress("42 Main St");
        paymentDetails1.setId(1);
        paymentDetails1.setPaymentMode(PaymentModes.COD);
        assertSame(paymentDetails1, this.paymentService.initiatePayment(paymentDetails1));
        verify(this.paymentDetailsRepository).save((PaymentDetails) any());
    }


    @Test
    void testInitiatePayment2() {
        PaymentDetails paymentDetails = new PaymentDetails();
        paymentDetails.setAddress("42 Main St");
        paymentDetails.setId(1);
        paymentDetails.setPaymentMode(PaymentModes.COD);
        when(this.paymentDetailsRepository.save((PaymentDetails) any())).thenReturn(paymentDetails);

        PaymentDetails paymentDetails1 = new PaymentDetails();
        paymentDetails1.setAddress("42 Main St");
        paymentDetails1.setId(1);
        paymentDetails1.setPaymentMode(PaymentModes.COD);
        assertSame(paymentDetails1, this.paymentService.initiatePayment(paymentDetails1));
        verify(this.paymentDetailsRepository).save((PaymentDetails) any());
    }
}

