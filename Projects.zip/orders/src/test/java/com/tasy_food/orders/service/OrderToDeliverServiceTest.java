package com.tasy_food.orders.service;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.any;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.tasy_food.orders.exception.DataNotFoundException;
import com.tasy_food.orders.model.OrderToDeliver;
import com.tasy_food.orders.repository.OrderToDeliverRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

@ContextConfiguration(classes = {OrderToDeliverService.class})
@ExtendWith(SpringExtension.class)
class OrderToDeliverServiceTest {
    @MockBean
    private OrderService orderService;

    @MockBean
    private OrderToDeliverRepository orderToDeliverRepository;

    @Autowired
    private OrderToDeliverService orderToDeliverService;

    /**
     * Method under test: {@link OrderToDeliverService#addOrderNumberToDelivery(Integer)}
     */
    @Test
    void testAddOrderNumberToDelivery() {
        OrderToDeliver orderToDeliver = new OrderToDeliver();
        orderToDeliver.setId(1);
        orderToDeliver.setOrderNumber(10);
        when(this.orderToDeliverRepository.save((OrderToDeliver) any())).thenReturn(orderToDeliver);
        this.orderToDeliverService.addOrderNumberToDelivery(10);
        verify(this.orderToDeliverRepository).save((OrderToDeliver) any());
    }

    /**
     * Method under test: {@link OrderToDeliverService#addOrderNumberToDelivery(Integer)}
     */
    @Test
    void testAddOrderNumberToDelivery2() {
        when(this.orderToDeliverRepository.save((OrderToDeliver) any()))
                .thenThrow(new DataNotFoundException("An error occurred"));
        assertThrows(DataNotFoundException.class, () -> this.orderToDeliverService.addOrderNumberToDelivery(10));
        verify(this.orderToDeliverRepository).save((OrderToDeliver) any());
    }

    @Test
    void testSetOrderDelivered() {
        when(this.orderToDeliverRepository.existsByOrderNumber((Integer) any())).thenReturn(true);
        doNothing().when(this.orderService).orderDelivered((Integer) any());
        assertThrows(DataNotFoundException.class, () -> this.orderToDeliverService.orderNumberExists(10));
        verify(this.orderToDeliverRepository).existsByOrderNumber((Integer) any());
        verify(this.orderService).orderDelivered((Integer) any());
    }

    @Test
    void testSetOrderDelivered2() {
        when(this.orderToDeliverRepository.existsByOrderNumber((Integer) any())).thenReturn(true);
        doThrow(new DataNotFoundException("An error occurred")).when(this.orderService).orderDelivered((Integer) any());
        assertThrows(DataNotFoundException.class, () -> this.orderToDeliverService.orderNumberExists(10));
        verify(this.orderToDeliverRepository).existsByOrderNumber((Integer) any());
        verify(this.orderService).orderDelivered((Integer) any());
    }

    /**
     * Method under test: {@link OrderToDeliverService#orderNumberExists(Integer)}
     */
    @Test
    void testSetOrderDelivered3() {
        when(this.orderToDeliverRepository.existsByOrderNumber((Integer) any())).thenReturn(true);
        doNothing().when(this.orderService).orderDelivered((Integer) any());
        assertThrows(DataNotFoundException.class, () -> this.orderToDeliverService.orderNumberExists(10));
        verify(this.orderToDeliverRepository).existsByOrderNumber((Integer) any());
        verify(this.orderService).orderDelivered((Integer) any());
    }

    /**
     * Method under test: {@link OrderToDeliverService#orderNumberExists(Integer)}
     */
    @Test
    void testSetOrderDelivered4() {
        when(this.orderToDeliverRepository.existsByOrderNumber((Integer) any())).thenReturn(true);
        doThrow(new DataNotFoundException("An error occurred")).when(this.orderService).orderDelivered((Integer) any());
        assertThrows(DataNotFoundException.class, () -> this.orderToDeliverService.orderNumberExists(10));
        verify(this.orderToDeliverRepository).existsByOrderNumber((Integer) any());
        verify(this.orderService).orderDelivered((Integer) any());
    }

}

