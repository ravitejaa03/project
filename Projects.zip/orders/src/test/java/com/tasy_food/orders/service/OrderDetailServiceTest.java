package com.tasy_food.orders.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.any;
import static org.mockito.Mockito.atLeast;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.tasy_food.orders.dto.PlaceOrderDTO;
import com.tasy_food.orders.dto.UpdateOrderDetailDTO;
import com.tasy_food.orders.exception.DataNotFoundException;
import com.tasy_food.orders.model.OrderDetail;
import com.tasy_food.orders.repository.OrderDetailRepository;

import java.util.ArrayList;
import java.util.Optional;

import org.junit.jupiter.api.Disabled;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

@ContextConfiguration(classes = {OrderDetailService.class})
@ExtendWith(SpringExtension.class)
class OrderDetailServiceTest {
    @MockBean
    private OrderDetailRepository orderDetailRepository;

    @Autowired
    private OrderDetailService orderDetailService;

    /**
     * Method under test: {@link OrderDetailService#saveOrderDetails(java.util.List)}
     */
    @Test
    void testSaveOrderDetails() {
        assertTrue(this.orderDetailService.saveOrderDetails(new ArrayList<>()).isEmpty());
    }

    /**
     * Method under test: {@link OrderDetailService#saveOrderDetails(java.util.List)}
     */
    @Test
    void testSaveOrderDetails2() {
        OrderDetail orderDetail = new OrderDetail();
        orderDetail.setFoodItemId(123);
        orderDetail.setId(1);
        orderDetail.setQuantity(1);
        when(this.orderDetailRepository.save((OrderDetail) any())).thenReturn(orderDetail);

        ArrayList<PlaceOrderDTO> placeOrderDTOList = new ArrayList<>();
        placeOrderDTOList.add(new PlaceOrderDTO());
        assertEquals(1, this.orderDetailService.saveOrderDetails(placeOrderDTOList).size());
        verify(this.orderDetailRepository).save((OrderDetail) any());
    }

    /**
     * Method under test: {@link OrderDetailService#saveOrderDetails(java.util.List)}
     */
    @Test
    void testSaveOrderDetails3() {
        OrderDetail orderDetail = new OrderDetail();
        orderDetail.setFoodItemId(123);
        orderDetail.setId(1);
        orderDetail.setQuantity(1);
        when(this.orderDetailRepository.save((OrderDetail) any())).thenReturn(orderDetail);

        ArrayList<PlaceOrderDTO> placeOrderDTOList = new ArrayList<>();
        placeOrderDTOList.add(new PlaceOrderDTO());
        placeOrderDTOList.add(new PlaceOrderDTO());
        assertEquals(1, this.orderDetailService.saveOrderDetails(placeOrderDTOList).size());
        verify(this.orderDetailRepository, atLeast(1)).save((OrderDetail) any());
    }

    /**
     * Method under test: {@link OrderDetailService#saveOrderDetails(java.util.List)}
     */
    @Test
    @Disabled("TODO: Complete this test")
    void testSaveOrderDetails4() {
        // TODO: Complete this test.
        //   Reason: R013 No inputs found that don't throw a trivial exception.
        //   Diffblue Cover tried to run the arrange/act section, but the method under
        //   test threw
        //   java.lang.NullPointerException
        //       at com.tasy_food.orders.service.OrderDetailService.lambda$saveOrderDetails$0(OrderDetailService.java:30)
        //       at java.util.ArrayList.forEach(ArrayList.java:1541)
        //       at com.tasy_food.orders.service.OrderDetailService.saveOrderDetails(OrderDetailService.java:28)
        //   In order to prevent saveOrderDetails(List)
        //   from throwing NullPointerException, add constructors or factory
        //   methods that make it easier to construct fully initialized objects used in
        //   saveOrderDetails(List).
        //   See https://diff.blue/R013 to resolve this issue.

        OrderDetail orderDetail = new OrderDetail();
        orderDetail.setFoodItemId(123);
        orderDetail.setId(1);
        orderDetail.setQuantity(1);
        when(this.orderDetailRepository.save((OrderDetail) any())).thenReturn(orderDetail);

        ArrayList<PlaceOrderDTO> placeOrderDTOList = new ArrayList<>();
        placeOrderDTOList.add(null);
        this.orderDetailService.saveOrderDetails(placeOrderDTOList);
    }

    /**
     * Method under test: {@link OrderDetailService#saveOrderDetails(java.util.List)}
     */
    @Test
    void testSaveOrderDetails5() {
        when(this.orderDetailRepository.save((OrderDetail) any()))
                .thenThrow(new DataNotFoundException("An error occurred"));

        ArrayList<PlaceOrderDTO> placeOrderDTOList = new ArrayList<>();
        placeOrderDTOList.add(new PlaceOrderDTO());
        assertThrows(DataNotFoundException.class, () -> this.orderDetailService.saveOrderDetails(placeOrderDTOList));
        verify(this.orderDetailRepository).save((OrderDetail) any());
    }

    /**
     * Method under test: {@link OrderDetailService#updateOrderDetails(UpdateOrderDetailDTO)}
     */
    @Test
    void testUpdateOrderDetails() {
        OrderDetail orderDetail = new OrderDetail();
        orderDetail.setFoodItemId(123);
        orderDetail.setId(1);
        orderDetail.setQuantity(1);
        Optional<OrderDetail> ofResult = Optional.of(orderDetail);

        OrderDetail orderDetail1 = new OrderDetail();
        orderDetail1.setFoodItemId(123);
        orderDetail1.setId(1);
        orderDetail1.setQuantity(1);
        when(this.orderDetailRepository.save((OrderDetail) any())).thenReturn(orderDetail1);
        when(this.orderDetailRepository.findById((Integer) any())).thenReturn(ofResult);
        this.orderDetailService.updateOrderDetails(new UpdateOrderDetailDTO());
        verify(this.orderDetailRepository).save((OrderDetail) any());
        verify(this.orderDetailRepository).findById((Integer) any());
    }

    /**
     * Method under test: {@link OrderDetailService#updateOrderDetails(UpdateOrderDetailDTO)}
     */
    @Test
    void testUpdateOrderDetails2() {
        OrderDetail orderDetail = new OrderDetail();
        orderDetail.setFoodItemId(123);
        orderDetail.setId(1);
        orderDetail.setQuantity(1);
        Optional<OrderDetail> ofResult = Optional.of(orderDetail);
        when(this.orderDetailRepository.save((OrderDetail) any()))
                .thenThrow(new DataNotFoundException("An error occurred"));
        when(this.orderDetailRepository.findById((Integer) any())).thenReturn(ofResult);
        assertThrows(DataNotFoundException.class,
                () -> this.orderDetailService.updateOrderDetails(new UpdateOrderDetailDTO()));
        verify(this.orderDetailRepository).save((OrderDetail) any());
        verify(this.orderDetailRepository).findById((Integer) any());
    }

    /**
     * Method under test: {@link OrderDetailService#updateOrderDetails(UpdateOrderDetailDTO)}
     */
    @Test
    void testUpdateOrderDetails3() {
        OrderDetail orderDetail = new OrderDetail();
        orderDetail.setFoodItemId(123);
        orderDetail.setId(1);
        orderDetail.setQuantity(1);
        when(this.orderDetailRepository.save((OrderDetail) any())).thenReturn(orderDetail);
        when(this.orderDetailRepository.findById((Integer) any())).thenReturn(Optional.empty());
        assertThrows(DataNotFoundException.class,
                () -> this.orderDetailService.updateOrderDetails(new UpdateOrderDetailDTO()));
        verify(this.orderDetailRepository).findById((Integer) any());
    }

    /**
     * Method under test: {@link OrderDetailService#updateOrderDetails(UpdateOrderDetailDTO)}
     */
    @Test
    @Disabled("TODO: Complete this test")
    void testUpdateOrderDetails4() {
        // TODO: Complete this test.
        //   Reason: R013 No inputs found that don't throw a trivial exception.
        //   Diffblue Cover tried to run the arrange/act section, but the method under
        //   test threw
        //   java.lang.NullPointerException
        //       at com.tasy_food.orders.service.OrderDetailService.updateOrderDetails(OrderDetailService.java:45)
        //   In order to prevent updateOrderDetails(UpdateOrderDetailDTO)
        //   from throwing NullPointerException, add constructors or factory
        //   methods that make it easier to construct fully initialized objects used in
        //   updateOrderDetails(UpdateOrderDetailDTO).
        //   See https://diff.blue/R013 to resolve this issue.

        OrderDetail orderDetail = new OrderDetail();
        orderDetail.setFoodItemId(123);
        orderDetail.setId(1);
        orderDetail.setQuantity(1);
        Optional<OrderDetail> ofResult = Optional.of(orderDetail);

        OrderDetail orderDetail1 = new OrderDetail();
        orderDetail1.setFoodItemId(123);
        orderDetail1.setId(1);
        orderDetail1.setQuantity(1);
        when(this.orderDetailRepository.save((OrderDetail) any())).thenReturn(orderDetail1);
        when(this.orderDetailRepository.findById((Integer) any())).thenReturn(ofResult);
        this.orderDetailService.updateOrderDetails(null);
    }
}

