package com.tasy_food.orders.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.any;
import static org.mockito.Mockito.atLeast;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.tasy_food.orders.consumers.MenuConsumer;
import com.tasy_food.orders.dao.OrderIdView;
import com.tasy_food.orders.dto.MenuDTO;
import com.tasy_food.orders.dto.UpdateOrderDetailDTO;
import com.tasy_food.orders.dto.ViewOrderDTO;
import com.tasy_food.orders.enums.DeliveryStatus;
import com.tasy_food.orders.enums.PaymentModes;
import com.tasy_food.orders.exception.DataNotFoundException;
import com.tasy_food.orders.exception.InternalErrorException;
import com.tasy_food.orders.model.Order;
import com.tasy_food.orders.model.OrderDetail;
import com.tasy_food.orders.model.PaymentDetails;
import com.tasy_food.orders.repository.OrderRepsitory;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

import java.util.Optional;
import java.util.Set;

import org.junit.jupiter.api.Disabled;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.web.server.ResponseStatusException;

@ContextConfiguration(classes = {OrderService.class})
@ExtendWith(SpringExtension.class)
class OrderServiceTest {
    @MockBean
    private MenuConsumer menuConsumer;

    @MockBean
    private OrderDetailService orderDetailService;

    @MockBean
    private OrderRepsitory orderRepsitory;

    @Autowired
    private OrderService orderService;

    @MockBean
    private PaymentService paymentService;


    @Test
    void testUpdateOrder() {
        OrderIdView orderIdView = mock(OrderIdView.class);
        when(orderIdView.getId()).thenReturn(1);
        Optional<OrderIdView> ofResult = Optional.of(orderIdView);
        when(this.orderRepsitory.findByOrderNumber((Integer) any())).thenReturn(ofResult);
        doNothing().when(this.orderDetailService).updateOrderDetails((UpdateOrderDetailDTO) any());
        this.orderService.updateOrder(10, new UpdateOrderDetailDTO());
        verify(this.orderRepsitory).findByOrderNumber((Integer) any());
        verify(orderIdView).getId();
        verify(this.orderDetailService).updateOrderDetails((UpdateOrderDetailDTO) any());
    }


    @Test
    void testUpdateOrder2() {
        OrderIdView orderIdView = mock(OrderIdView.class);
        when(orderIdView.getId()).thenReturn(1);
        Optional<OrderIdView> ofResult = Optional.of(orderIdView);
        when(this.orderRepsitory.findByOrderNumber((Integer) any())).thenReturn(ofResult);
        doThrow(new InternalErrorException("Msg")).when(this.orderDetailService)
                .updateOrderDetails((UpdateOrderDetailDTO) any());
        assertThrows(InternalErrorException.class, () -> this.orderService.updateOrder(10, new UpdateOrderDetailDTO()));
        verify(this.orderRepsitory).findByOrderNumber((Integer) any());
        verify(orderIdView).getId();
        verify(this.orderDetailService).updateOrderDetails((UpdateOrderDetailDTO) any());
    }


    @Test
    void testUpdateOrder3() {
        when(this.orderRepsitory.findByOrderNumber((Integer) any())).thenReturn(Optional.empty());
        doNothing().when(this.orderDetailService).updateOrderDetails((UpdateOrderDetailDTO) any());
        assertThrows(DataNotFoundException.class, () -> this.orderService.updateOrder(10, new UpdateOrderDetailDTO()));
        verify(this.orderRepsitory).findByOrderNumber((Integer) any());
    }



    @Test
    void testGetOrder() {
        OrderIdView orderIdView = mock(OrderIdView.class);
        when(orderIdView.getId()).thenReturn(1);
        Optional<OrderIdView> ofResult = Optional.of(orderIdView);

        PaymentDetails paymentDetails = new PaymentDetails();
        paymentDetails.setAddress("42 Main St");
        paymentDetails.setId(1);
        paymentDetails.setPaymentMode(PaymentModes.COD);

        Order order = new Order();
        order.setId(1);
        order.setOrderDetails(new HashSet<>());
        order.setOrderNumber(10);
        order.setPaymentDetails(paymentDetails);
        order.setStatus(DeliveryStatus.DELIVERED);
        Optional<Order> ofResult1 = Optional.of(order);
        when(this.orderRepsitory.findById((Integer) any())).thenReturn(ofResult1);
        when(this.orderRepsitory.findByOrderNumber((Integer) any())).thenReturn(ofResult);
        ViewOrderDTO actualOrder = this.orderService.getOrder(10);
        assertEquals(0, actualOrder.getItemsAvailable());
        assertTrue(actualOrder.isPaymentDone());
        assertEquals(0.0d, actualOrder.getTotalPay());
        assertSame(paymentDetails, actualOrder.getPaymentDetail());
        assertEquals(10, actualOrder.getOrderNumber().intValue());
        assertEquals(0, actualOrder.getItemsOrdered());
        assertTrue(actualOrder.getOrderList().isEmpty());
        verify(this.orderRepsitory).findByOrderNumber(any());
        verify(this.orderRepsitory).findById(any());
        verify(orderIdView, atLeast(1)).getId();
    }


    @Test
    void testGetOrder2() {
        OrderIdView orderIdView = mock(OrderIdView.class);
        when(orderIdView.getId()).thenThrow(new InternalErrorException("Msg"));
        Optional<OrderIdView> ofResult = Optional.of(orderIdView);

        PaymentDetails paymentDetails = new PaymentDetails();
        paymentDetails.setAddress("42 Main St");
        paymentDetails.setId(1);
        paymentDetails.setPaymentMode(PaymentModes.COD);

        Order order = new Order();
        order.setId(1);
        order.setOrderDetails(new HashSet<>());
        order.setOrderNumber(10);
        order.setPaymentDetails(paymentDetails);
        order.setStatus(DeliveryStatus.DELIVERED);
        Optional<Order> ofResult1 = Optional.of(order);
        when(this.orderRepsitory.findById((Integer) any())).thenReturn(ofResult1);
        when(this.orderRepsitory.findByOrderNumber((Integer) any())).thenReturn(ofResult);
        assertThrows(InternalErrorException.class, () -> this.orderService.getOrder(10));
        verify(this.orderRepsitory).findByOrderNumber((Integer) any());
        verify(orderIdView).getId();
    }


    @Test
    void testUpdatePaymentDetails() {
        doNothing().when(this.paymentService).updatePayment((PaymentDetails) any());
        OrderIdView orderIdView = mock(OrderIdView.class);
        when(orderIdView.getId()).thenReturn(1);
        Optional<OrderIdView> ofResult = Optional.of(orderIdView);

        PaymentDetails paymentDetails = new PaymentDetails();
        paymentDetails.setAddress("42 Main St");
        paymentDetails.setId(1);
        paymentDetails.setPaymentMode(PaymentModes.COD);

        Order order = new Order();
        order.setId(1);
        order.setOrderDetails(new HashSet<>());
        order.setOrderNumber(10);
        order.setPaymentDetails(paymentDetails);
        order.setStatus(DeliveryStatus.DELIVERED);
        Optional<Order> ofResult1 = Optional.of(order);
        when(this.orderRepsitory.findById((Integer) any())).thenReturn(ofResult1);
        when(this.orderRepsitory.findByOrderNumber((Integer) any())).thenReturn(ofResult);

        PaymentDetails paymentDetails1 = new PaymentDetails();
        paymentDetails1.setAddress("43 Main St");
        paymentDetails1.setId(1);
        paymentDetails1.setPaymentMode(PaymentModes.COD);
        this.orderService.updatePaymentDetails(10, paymentDetails1);
        verify(this.paymentService).updatePayment((PaymentDetails) any());
        verify(this.orderRepsitory).findByOrderNumber((Integer) any());
        verify(this.orderRepsitory).findById((Integer) any());
        verify(orderIdView, atLeast(1)).getId();
    }

    @Test
    void testUpdatePaymentDetails2() {
        doNothing().when(this.paymentService).updatePayment((PaymentDetails) any());
        OrderIdView orderIdView = mock(OrderIdView.class);
        when(orderIdView.getId()).thenThrow(new InternalErrorException("Msg"));
        Optional<OrderIdView> ofResult = Optional.of(orderIdView);

        PaymentDetails paymentDetails = new PaymentDetails();
        paymentDetails.setAddress("42 Main St");
        paymentDetails.setId(1);
        paymentDetails.setPaymentMode(PaymentModes.COD);

        Order order = new Order();
        order.setId(1);
        order.setOrderDetails(new HashSet<>());
        order.setOrderNumber(10);
        order.setPaymentDetails(paymentDetails);
        order.setStatus(DeliveryStatus.DELIVERED);
        Optional<Order> ofResult1 = Optional.of(order);
        when(this.orderRepsitory.findById((Integer) any())).thenReturn(ofResult1);
        when(this.orderRepsitory.findByOrderNumber((Integer) any())).thenReturn(ofResult);

        PaymentDetails paymentDetails1 = new PaymentDetails();
        paymentDetails1.setAddress("42 Main St");
        paymentDetails1.setId(1);
        paymentDetails1.setPaymentMode(PaymentModes.COD);
        assertThrows(InternalErrorException.class, () -> this.orderService.updatePaymentDetails(10, paymentDetails1));
        verify(this.orderRepsitory).findByOrderNumber((Integer) any());
        verify(orderIdView).getId();
    }

    @Test
    void testPlaceOrder() {
        OrderIdView orderIdView = mock(OrderIdView.class);
        when(orderIdView.getId()).thenReturn(1);
        Optional<OrderIdView> ofResult = Optional.of(orderIdView);

        PaymentDetails paymentDetails = new PaymentDetails();
        paymentDetails.setAddress("42 Main St");
        paymentDetails.setId(1);
        paymentDetails.setPaymentMode(PaymentModes.COD);

        Order order = new Order();
        order.setId(1);
        order.setOrderDetails(new HashSet<>());
        order.setOrderNumber(10);
        order.setPaymentDetails(paymentDetails);
        order.setStatus(DeliveryStatus.DELIVERED);
        Optional<Order> ofResult1 = Optional.of(order);
        when(this.orderRepsitory.findById((Integer) any())).thenReturn(ofResult1);
        when(this.orderRepsitory.findByOrderNumber((Integer) any())).thenReturn(ofResult);
        assertThrows(InternalErrorException.class, () -> this.orderService.placeOrder(10));
        verify(this.orderRepsitory).findByOrderNumber((Integer) any());
        verify(this.orderRepsitory).findById((Integer) any());
        verify(orderIdView).getId();
    }

    @Test
    void testPlaceOrder2() {
        OrderIdView orderIdView = mock(OrderIdView.class);
        when(orderIdView.getId()).thenThrow(new InternalErrorException("Msg"));
        Optional<OrderIdView> ofResult = Optional.of(orderIdView);

        PaymentDetails paymentDetails = new PaymentDetails();
        paymentDetails.setAddress("42 Main St");
        paymentDetails.setId(1);
        paymentDetails.setPaymentMode(PaymentModes.COD);

        Order order = new Order();
        order.setId(1);
        order.setOrderDetails(new HashSet<>());
        order.setOrderNumber(10);
        order.setPaymentDetails(paymentDetails);
        order.setStatus(DeliveryStatus.DELIVERED);
        Optional<Order> ofResult1 = Optional.of(order);
        when(this.orderRepsitory.findById((Integer) any())).thenReturn(ofResult1);
        when(this.orderRepsitory.findByOrderNumber((Integer) any())).thenReturn(ofResult);
        assertThrows(InternalErrorException.class, () -> this.orderService.placeOrder(10));
        verify(this.orderRepsitory).findByOrderNumber((Integer) any());
        verify(orderIdView).getId();
    }


    @Test
    void testPlaceOrder3() {
        OrderIdView orderIdView = mock(OrderIdView.class);
        when(orderIdView.getId()).thenReturn(1);
        Optional<OrderIdView> ofResult = Optional.of(orderIdView);

        PaymentDetails paymentDetails = new PaymentDetails();
        paymentDetails.setAddress("42 Main St");
        paymentDetails.setId(1);
        paymentDetails.setPaymentMode(PaymentModes.COD);

        PaymentDetails paymentDetails1 = new PaymentDetails();
        paymentDetails1.setAddress("42 Main St");
        paymentDetails1.setId(1);
        paymentDetails1.setPaymentMode(PaymentModes.COD);

        OrderDetail orderDetail = new OrderDetail();
        orderDetail.setFoodItemId(123);
        orderDetail.setId(1);
        orderDetail.setQuantity(1);

        HashSet<OrderDetail> orderDetailSet = new HashSet<>();
        orderDetailSet.add(orderDetail);
        Order order = mock(Order.class);
        when(order.getOrderDetails()).thenReturn(orderDetailSet);
        when(order.getStatus()).thenReturn(DeliveryStatus.NOT_DELIVERED);
        when(order.getPaymentDetails()).thenReturn(paymentDetails1);
        doNothing().when(order).setId((Integer) any());
        doNothing().when(order).setOrderDetails((Set<OrderDetail>) any());
        doNothing().when(order).setOrderNumber((Integer) any());
        doNothing().when(order).setPaymentDetails((PaymentDetails) any());
        doNothing().when(order).setStatus((DeliveryStatus) any());
        order.setId(1);
        order.setOrderDetails(new HashSet<>());
        order.setOrderNumber(10);
        order.setPaymentDetails(paymentDetails);
        order.setStatus(DeliveryStatus.DELIVERED);
        Optional<Order> ofResult1 = Optional.of(order);

        PaymentDetails paymentDetails2 = new PaymentDetails();
        paymentDetails2.setAddress("42 Main St");
        paymentDetails2.setId(1);
        paymentDetails2.setPaymentMode(PaymentModes.COD);

        Order order1 = new Order();
        order1.setId(1);
        order1.setOrderDetails(new HashSet<>());
        order1.setOrderNumber(10);
        order1.setPaymentDetails(paymentDetails2);
        order1.setStatus(DeliveryStatus.DELIVERED);
        when(this.orderRepsitory.save((Order) any())).thenReturn(order1);
        when(this.orderRepsitory.findById((Integer) any())).thenReturn(ofResult1);
        when(this.orderRepsitory.findByOrderNumber((Integer) any())).thenReturn(ofResult);
        when(this.menuConsumer.updateQuantityForFoodItems((Set<com.tasy_food.orders.dto.PlaceOrderDTO>) any()))
                .thenReturn(true);
        this.orderService.placeOrder(10);
        verify(this.orderRepsitory).save((Order) any());
        verify(this.orderRepsitory).findByOrderNumber((Integer) any());
        verify(this.orderRepsitory).findById((Integer) any());
        verify(order).getStatus();
        verify(order).getPaymentDetails();
        verify(order).getOrderDetails();
        verify(order).setId((Integer) any());
        verify(order).setOrderDetails((Set<OrderDetail>) any());
        verify(order).setOrderNumber((Integer) any());
        verify(order).setPaymentDetails((PaymentDetails) any());
        verify(order, atLeast(1)).setStatus((DeliveryStatus) any());
        verify(orderIdView).getId();
        verify(this.menuConsumer).updateQuantityForFoodItems((Set<com.tasy_food.orders.dto.PlaceOrderDTO>) any());
    }


    @Test
    void testOrderDelivered() {
        OrderIdView orderIdView = mock(OrderIdView.class);
        when(orderIdView.getId()).thenReturn(1);
        Optional<OrderIdView> ofResult = Optional.of(orderIdView);

        PaymentDetails paymentDetails = new PaymentDetails();
        paymentDetails.setAddress("42 Main St");
        paymentDetails.setId(1);
        paymentDetails.setPaymentMode(PaymentModes.COD);

        Order order = new Order();
        order.setId(1);
        order.setOrderDetails(new HashSet<>());
        order.setOrderNumber(10);
        order.setPaymentDetails(paymentDetails);
        order.setStatus(DeliveryStatus.DELIVERED);
        Optional<Order> ofResult1 = Optional.of(order);
        when(this.orderRepsitory.findById((Integer) any())).thenReturn(ofResult1);
        when(this.orderRepsitory.findByOrderNumber((Integer) any())).thenReturn(ofResult);
        assertThrows(ResponseStatusException.class, () -> this.orderService.orderDelivered(10));
        verify(this.orderRepsitory).findByOrderNumber((Integer) any());
        verify(this.orderRepsitory).findById((Integer) any());
        verify(orderIdView).getId();
    }


    @Test
    void testOrderDelivered2() {
        OrderIdView orderIdView = mock(OrderIdView.class);
        when(orderIdView.getId()).thenReturn(1);
        Optional<OrderIdView> ofResult = Optional.of(orderIdView);

        PaymentDetails paymentDetails = new PaymentDetails();
        paymentDetails.setAddress("42 Main St");
        paymentDetails.setId(1);
        paymentDetails.setPaymentMode(PaymentModes.COD);
        Order order = mock(Order.class);
        when(order.getStatus()).thenReturn(DeliveryStatus.DISPATCHED);
        doNothing().when(order).setId((Integer) any());
        doNothing().when(order).setOrderDetails((java.util.Set<OrderDetail>) any());
        doNothing().when(order).setOrderNumber((Integer) any());
        doNothing().when(order).setPaymentDetails((PaymentDetails) any());
        doNothing().when(order).setStatus((DeliveryStatus) any());
        order.setId(1);
        order.setOrderDetails(new HashSet<>());
        order.setOrderNumber(10);
        order.setPaymentDetails(paymentDetails);
        order.setStatus(DeliveryStatus.DELIVERED);
        Optional<Order> ofResult1 = Optional.of(order);
        when(this.orderRepsitory.save((Order) any())).thenThrow(new InternalErrorException("Msg"));
        when(this.orderRepsitory.findById((Integer) any())).thenReturn(ofResult1);
        when(this.orderRepsitory.findByOrderNumber((Integer) any())).thenReturn(ofResult);
        assertThrows(InternalErrorException.class, () -> this.orderService.orderDelivered(10));
        verify(this.orderRepsitory).save((Order) any());
        verify(this.orderRepsitory).findByOrderNumber((Integer) any());
        verify(this.orderRepsitory).findById((Integer) any());
        verify(order).getStatus();
        verify(order).setId((Integer) any());
        verify(order).setOrderDetails((java.util.Set<OrderDetail>) any());
        verify(order).setOrderNumber((Integer) any());
        verify(order).setPaymentDetails((PaymentDetails) any());
        verify(order, atLeast(1)).setStatus((DeliveryStatus) any());
        verify(orderIdView).getId();
    }

    @Test
    void testDeleteOrder() {
        OrderIdView orderIdView = mock(OrderIdView.class);
        when(orderIdView.getId()).thenReturn(1);
        Optional<OrderIdView> ofResult = Optional.of(orderIdView);
        doNothing().when(this.orderRepsitory).deleteById((Integer) any());
        when(this.orderRepsitory.findByOrderNumber((Integer) any())).thenReturn(ofResult);
        this.orderService.deleteOrder(10);
        verify(this.orderRepsitory).findByOrderNumber((Integer) any());
        verify(this.orderRepsitory).deleteById((Integer) any());
        verify(orderIdView, atLeast(1)).getId();
    }

    @Test
    void testDeleteOrder2() {
        doNothing().when(this.orderRepsitory).deleteById((Integer) any());
        when(this.orderRepsitory.findByOrderNumber((Integer) any())).thenReturn(Optional.empty());
        assertThrows(DataNotFoundException.class, () -> this.orderService.deleteOrder(10));
        verify(this.orderRepsitory).findByOrderNumber((Integer) any());
    }


    @Test
    void testGetOrderId() {
        when(this.orderRepsitory.findByOrderNumber((Integer) any())).thenReturn(Optional.of(mock(OrderIdView.class)));
        this.orderService.getOrderId(10);
        verify(this.orderRepsitory).findByOrderNumber((Integer) any());
    }

    @Test
    void testGetOrderId2() {
        when(this.orderRepsitory.findByOrderNumber((Integer) any())).thenReturn(Optional.empty());
        assertThrows(DataNotFoundException.class, () -> this.orderService.getOrderId(10));
        verify(this.orderRepsitory).findByOrderNumber((Integer) any());
    }


    @Test
    void testGetMenu() {
        assertTrue(this.orderService.getMenu(new HashSet<>()).isEmpty());
    }


    @Test
    void testGetMenu2() {
        when(this.menuConsumer.getMenuForAvailableQuantity((Integer) any(), (Integer) any())).thenReturn(new MenuDTO());

        OrderDetail orderDetail = new OrderDetail();
        orderDetail.setFoodItemId(123);
        orderDetail.setId(1);
        orderDetail.setQuantity(1);

        HashSet<OrderDetail> orderDetailSet = new HashSet<>();
        orderDetailSet.add(orderDetail);
        assertEquals(1, this.orderService.getMenu(orderDetailSet).size());
        verify(this.menuConsumer).getMenuForAvailableQuantity((Integer) any(), (Integer) any());
    }



}

