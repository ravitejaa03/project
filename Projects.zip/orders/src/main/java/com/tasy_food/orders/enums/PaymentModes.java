package com.tasy_food.orders.enums;

public enum PaymentModes {
    COD,
    UPI,
    DEBIT_CARD,
    CREDIT_CARD
}
