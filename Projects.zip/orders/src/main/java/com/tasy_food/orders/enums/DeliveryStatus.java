package com.tasy_food.orders.enums;

public enum DeliveryStatus {

    DELIVERED,
    NOT_DELIVERED,
    DISPATCHED;
}
