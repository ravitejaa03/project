package com.tasy_food.orders.consumers;

import com.tasy_food.orders.dto.MenuDTO;
import com.tasy_food.orders.dto.PlaceOrderDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;

import java.util.Set;

@FeignClient(name="restaurants-service")
@RequestMapping("/api/v1/menu")
public interface MenuConsumer {

    @GetMapping(path = "/available")
     MenuDTO getMenuForAvailableQuantity(@RequestParam("id") Integer foodId, @RequestParam("req") Integer requiredQuantity);

    @PutMapping(path = "/quantities")
    boolean updateQuantityForFoodItems(@RequestBody Set<PlaceOrderDTO> placeOrderSet);
}
