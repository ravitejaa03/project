package com.tasy_food.orders.service;

import com.tasy_food.orders.enums.PaymentModes;
import com.tasy_food.orders.model.PaymentDetails;
import com.tasy_food.orders.repository.PaymentDetailsRepository;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Service
@AllArgsConstructor
@Slf4j
public class PaymentService {

    private final PaymentDetailsRepository paymentDetailsRepository;

    public void updatePayment(PaymentDetails paymentDetails1) {
        PaymentDetails paymentDetails = initiatePayment(paymentDetails1);
        log.info("Updated payment details: "+paymentDetails);
    }
    public PaymentDetails initiatePayment(PaymentDetails paymentDetails){
        paymentDetailsRepository.save(paymentDetails);
        log.info("Payment initiated with details: "+paymentDetails);
        return paymentDetails;

    }


}
