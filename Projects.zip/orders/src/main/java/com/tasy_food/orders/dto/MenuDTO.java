package com.tasy_food.orders.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class MenuDTO {

    private Integer menuId;
    private String itemName;
    private String itemDescription;
    private double itemPrice;
    private CostDTO cost;
}
