package com.tasy_food.orders.repository;

import com.tasy_food.orders.dao.OrderIdView;
import com.tasy_food.orders.model.Order;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface OrderRepsitory extends JpaRepository<Order, Integer> {


    Optional<OrderIdView> findByOrderNumber(Integer orderNumber);

    boolean existsByOrderNumber(Integer orderNumber);






}
