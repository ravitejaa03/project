package com.tasy_food.orders.dao;

public interface OrderIdView {

    Integer getId();
}
