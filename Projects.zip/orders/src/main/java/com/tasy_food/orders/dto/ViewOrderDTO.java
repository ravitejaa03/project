package com.tasy_food.orders.dto;

import com.tasy_food.orders.model.PaymentDetails;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.HashSet;
import java.util.Set;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class ViewOrderDTO {

    private Integer orderNumber;
    private double totalPay;
    private boolean paymentDone ;
    private int itemsOrdered;
    private int itemsAvailable;
    private Set<MenuDTO> orderList;
    private PaymentDetails paymentDetail;
}
