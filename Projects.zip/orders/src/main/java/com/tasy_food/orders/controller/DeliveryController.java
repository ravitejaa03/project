package com.tasy_food.orders.controller;

import com.tasy_food.orders.exception.DataNotFoundException;
import com.tasy_food.orders.service.OrderService;
import com.tasy_food.orders.service.OrderToDeliverService;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@Slf4j
@AllArgsConstructor
@RequestMapping("/api/v1/delivery")
public class DeliveryController {

    private final OrderToDeliverService deliverService;
    private final OrderService orderService;

    @PatchMapping("/{orderNumber}/complete")
    public ResponseEntity<String> deliverOrder(@PathVariable("orderNumber") Integer orderNumber){
        log.info("Request to set order "+orderNumber+" delivered.");
        if(!deliverService.orderNumberExists(orderNumber))
            throw new DataNotFoundException("Order "+orderNumber+" does not exist in delivery queue");
        orderService.orderDelivered(orderNumber);
        log.info("Order "+orderNumber+" changed to delivered.");
        return ResponseEntity.ok("Order "+orderNumber+" delivered successfully.");
    }
}
