package com.tasy_food.orders.model;

import com.tasy_food.orders.enums.DeliveryStatus;
import lombok.*;
import org.hibernate.Hibernate;

import javax.persistence.*;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import java.util.Objects;
import java.util.Set;

@Entity
@Table(name = "orders", indexes = {
        @Index(name = "idx_order_ordernumber", columnList = "orderNumber")
})
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class Order {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Integer id;

    @Min(10000) @Max(100000)
    @Column(nullable = false, unique = true)
    private Integer orderNumber;

    @Column(nullable = false)
    private DeliveryStatus status;

    @OneToMany(cascade = CascadeType.REMOVE)
    @JoinTable(name = "order_orderDetail_mapping", joinColumns= @JoinColumn(name = "order_id")
            , inverseJoinColumns = @JoinColumn(name = "order_detail_id")
    )
    private Set<OrderDetail> orderDetails;

    @OneToOne(cascade = CascadeType.REMOVE)
    private PaymentDetails paymentDetails;

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || Hibernate.getClass(this) != Hibernate.getClass(o)) return false;
        Order order = (Order) o;
        return id != null && Objects.equals(id, order.id);
    }

    @Override
    public int hashCode() {
        return getClass().hashCode();
    }

    @Override
    public String toString() {
        return getClass().getSimpleName() + "(" +
                "id = " + id + ", " +
                "orderNumber = " + orderNumber + ", " +
                "status = " + status + ", " +
                "paymentDetails = " + paymentDetails + ")";
    }
}
