package com.tasy_food.orders.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class UpdateOrderDetailDTO {

    @NotNull(message = "Id cannot be empty.")
    @Min(value = 0, message = "Id cannot be less than 0")
    public Integer id;
    @NotNull(message = "Food item id cannot be empty.")
    @Min(value = 0, message = "Food item id cannot be less than 0")
    public Integer foodItemId;
    @NotNull(message = "Quantity cannot be empty.")
    @Min(value = 0, message = "Quantity cannot be less than 0")
    public Integer quantity;
}
