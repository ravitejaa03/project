package com.tasy_food.orders.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class PlaceOrderDTO {

    @NotEmpty(message = "Food item id cannot be empty.")
    @Min(value = 0, message = "Food item id cannot be less than 0")
    public Integer foodItemId;
    @NotEmpty(message = "Quantity cannot be empty.")
    @Min(value = 0, message = "Quantity cannot be less than 0")
    public Integer quantity;
}
