package com.tasy_food.orders.service;

import com.tasy_food.orders.model.OrderToDeliver;
import com.tasy_food.orders.repository.OrderToDeliverRepository;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@AllArgsConstructor
@Slf4j
@Service
public class OrderToDeliverService {

    private final OrderToDeliverRepository orderToDeliverRepository;

    public  void addOrderNumberToDelivery(Integer orderNumber){
        OrderToDeliver orderToDeliver = new OrderToDeliver();
        orderToDeliver.setOrderNumber(orderNumber);
        orderToDeliverRepository.save(orderToDeliver);
        log.info("Order to delivery saved: "+orderToDeliver.toString());
    }
    public boolean orderNumberExists(Integer orderNumber){
       return orderToDeliverRepository.existsByOrderNumber(orderNumber);
    }
}
