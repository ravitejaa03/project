package com.tasy_food.orders.controller;


import com.tasy_food.orders.dto.PlaceOrderDTO;
import com.tasy_food.orders.dto.UpdateOrderDetailDTO;
import com.tasy_food.orders.dto.ViewOrderDTO;
import com.tasy_food.orders.model.PaymentDetails;
import com.tasy_food.orders.service.OrderService;
import io.github.resilience4j.retry.annotation.Retry;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.HashSet;
import java.util.List;

@RestController
@RequestMapping("/api/v1/orders")
@AllArgsConstructor
@Slf4j
public class OrdersController {

    private final OrderService orderService;

    @PostMapping
    public ResponseEntity<String> createOrder(@Validated @RequestBody List<PlaceOrderDTO> placeOrder){
        log.info("Request to place order :"+placeOrder.toString());
        Integer orderNumber = orderService.saveOrder(placeOrder);
        return ResponseEntity.status(HttpStatus.CREATED).body("Order placed successfully. Your order number is: "+orderNumber);

    }

    @GetMapping("/{orderNumber}")
    public ResponseEntity<ViewOrderDTO> viewOrder(@PathVariable("orderNumber") Integer orderNumber){
        log.info("Request to view order number: "+orderNumber);
        ViewOrderDTO order = orderService.getOrder(orderNumber);
        log.info("Order number "+orderNumber+" retrieved successfully");
        return ResponseEntity.ok(order);
    }


    @PatchMapping("/{orderNumber}/details")
    public ResponseEntity<String> updateOrderDetail(@PathVariable("orderNumber") Integer orderNumber,
                                                    @Validated @RequestBody UpdateOrderDetailDTO updateOrderDetail){
        log.info("Request to update order "+orderNumber+" details as: "+updateOrderDetail.toString());
        orderService.updateOrder(orderNumber, updateOrderDetail);
        log.info("Order "+orderNumber+" details updated");
        return ResponseEntity.status(HttpStatus.ACCEPTED).body("Details for order "+orderNumber+" updated.");
    }

    @PatchMapping("/{orderNumber}/payment")
    public ResponseEntity<String> updatePaymentDetails(@PathVariable("orderNumber") Integer orderNumber,
                                                       @Validated @RequestBody PaymentDetails paymentDetails){
        log.info("Request to update order "+orderNumber+" with payment details "+paymentDetails.toString());
        orderService.updatePaymentDetails(orderNumber, paymentDetails);
        log.info("Payment details updated for order "+orderNumber);
        return ResponseEntity.status(HttpStatus.CREATED).body("Payment details updated for order "+ orderNumber);

    }

    @PatchMapping("/{orderNumber}/place")
    public ResponseEntity<String> placeOrder(@PathVariable("orderNumber") Integer orderNumber){
        log.info("Request to place order "+orderNumber+" started");
        orderService.placeOrder(orderNumber);
        log.info("Order "+orderNumber+" placed successfully.");
        return ResponseEntity.status(HttpStatus.ACCEPTED).body("Your order "+orderNumber+" placed successfully, will" +
                "be delivered to your respective address shortly.");
    }

    @DeleteMapping("/{orderNumber}")
    public ResponseEntity<String> deleteOrder(@PathVariable("orderNumber") Integer orderNumber){
        log.info("Request to delete order number: "+orderNumber);
        orderService.deleteOrder(orderNumber);
        return ResponseEntity.ok("Order number: "+orderNumber+" deleted successfully.");
    }


}
