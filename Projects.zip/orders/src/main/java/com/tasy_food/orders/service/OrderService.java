package com.tasy_food.orders.service;

import com.tasy_food.orders.consumers.MenuConsumer;
import com.tasy_food.orders.dao.OrderIdView;
import com.tasy_food.orders.dto.*;
import com.tasy_food.orders.enums.DeliveryStatus;
import com.tasy_food.orders.exception.DataNotFoundException;
import com.tasy_food.orders.exception.InternalErrorException;
import com.tasy_food.orders.model.Order;
import com.tasy_food.orders.model.OrderDetail;
import com.tasy_food.orders.model.PaymentDetails;
import com.tasy_food.orders.repository.OrderRepsitory;
import io.github.resilience4j.retry.annotation.Retry;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Lazy;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.concurrent.ThreadLocalRandom;
import java.util.function.Supplier;

@Service
@AllArgsConstructor
@Slf4j
public class OrderService {

    private final OrderRepsitory orderRepsitory;
    private final OrderDetailService orderDetailService;
    private final PaymentService paymentService;
    private final MenuConsumer menuConsumer;
    private final OrderToDeliverService toDeliverService;
    public static final String ORDER_SERVICE="orderService";

    @Transactional
    public Integer saveOrder(List<PlaceOrderDTO> placeOrder){
        Integer orderNumber = 0;
        try {
            Set<OrderDetail> savedOrderDetailSet = orderDetailService.saveOrderDetails(placeOrder);
            log.info("Total saved order details: "+savedOrderDetailSet.size()+" generating order number");

            orderNumber = getRandomOrderNumber();
            log.info("Generated order number: "+orderNumber);

            Order order = new Order();
            order.setOrderDetails(savedOrderDetailSet);
            order.setOrderNumber(orderNumber);
            order.setStatus(DeliveryStatus.NOT_DELIVERED);
            orderRepsitory.save(order);
            log.info("Saved order: "+order.toString());

        }catch (Exception ex){
            log.error("Error occurred while creating order ", ex);
            throw new InternalErrorException("Sorry..! your order could not be saved. Please try again later.");
        }
        return orderNumber;
    }

    public void updateOrder(Integer orderNumber, UpdateOrderDetailDTO updateOrderDetail) {
        OrderIdView orderId = getOrderId(orderNumber);
        log.info("Updating order number "+orderNumber+" with id: "+orderId.getId()+" with details: "+updateOrderDetail);
        orderDetailService.updateOrderDetails(updateOrderDetail);
    }

    public Integer getRandomOrderNumber(){
        Supplier<Integer> getRandomNumber = () -> ThreadLocalRandom.current().nextInt(10000, 100000);
        Integer orderNumber = getRandomNumber.get();
        while(orderRepsitory.existsByOrderNumber(orderNumber)){
            log.info("Order number: "+orderNumber+" exist generating new order number.");
            orderNumber = getRandomNumber.get();
        }
        return orderNumber;
    }

    public ViewOrderDTO getOrder(Integer orderNumber){

        OrderIdView orderIdView = getOrderId(orderNumber);
        log.info("Id for order number"+orderNumber+" is: "+orderIdView.getId());
        try {
            Order order = orderRepsitory.findById(orderIdView.getId()).get();
            log.info("Data for order number" +orderNumber+": "+ order.toString());

            int itemsOrdered = order.getOrderDetails().size();
            final Set<MenuDTO> menu = getMenu(order.getOrderDetails());
            int itemsAvailable = menu.size();
            double totalPay = calculateTotalPay(menu);
            boolean paymentDone = order.getPaymentDetails() != null;
            ViewOrderDTO viewOrder =
                    new ViewOrderDTO(orderNumber,totalPay, paymentDone, itemsOrdered, itemsAvailable, menu,
                            order.getPaymentDetails());
            return viewOrder;
        }catch (Exception ex){
            log.error("Some error occurred while retrieving order number "+orderNumber, ex);
            throw new InternalErrorException("Sorry...! order number: "+orderNumber+" could not be retrieved for now. Please try again later.");
        }

    }

    private double calculateTotalPay(Set<MenuDTO> menuSet) {

        double totalPay = 0.00;
            for (MenuDTO menu : menuSet)
                totalPay += menu.getCost().getCost();

        return totalPay;
    }

    public void updatePaymentDetails(Integer orderNumber, PaymentDetails paymentDetails) {
        OrderIdView orderIdView = getOrderId(orderNumber);
        log.info("Id for order number"+orderNumber+" is: "+orderIdView.getId());

        Order order = orderRepsitory.findById(orderIdView.getId()).get();
        if(order.getPaymentDetails() == null ){
            log.info("Payment details not added for order "+orderNumber+". Adding new details.");
             paymentDetails = paymentService.initiatePayment(paymentDetails);
            order.setPaymentDetails(paymentDetails);
            orderRepsitory.save(order);
            log.info("Payment details added for order "+orderNumber+ " with details");
        }else{
            PaymentDetails paymentDetails1 = order.getPaymentDetails();
            paymentDetails1.setPaymentMode(paymentDetails.getPaymentMode());
            paymentDetails1.setAddress(paymentDetails.getAddress());
            paymentService.updatePayment(paymentDetails1);
        }

    }

    public void placeOrder(Integer orderNumber) {
        OrderIdView orderIdView = getOrderId(orderNumber);

        Order order = orderRepsitory.findById(orderIdView.getId()).get();

        if(order.getPaymentDetails() == null)
            throw new DataNotFoundException("Sorry payment details not found for order " +orderNumber+
                    ". Please update the payment details before placing the order for delivery.");

        DeliveryStatus orderStatus = order.getStatus();
        if(orderStatus.equals(DeliveryStatus.DELIVERED) || orderStatus.equals(DeliveryStatus.DISPATCHED))
            throw new  InternalErrorException("Order "+orderNumber+" is already "+orderStatus.toString().toLowerCase()+" .");

        try {
            boolean updated = updateFoodItemQuantities(order.getOrderDetails());
            if(updated){
                order.setStatus(DeliveryStatus.DISPATCHED);
                orderRepsitory.save(order);
                toDeliverService.addOrderNumberToDelivery(orderNumber);
            }else{
                throw new InternalErrorException("updateQuantityResponse.getReason().toString()");
            }

        }catch (Exception ex){
            log.error("Error while placing order for "+orderNumber,ex);
            throw new InternalErrorException("Sorry your order "+orderNumber+ " could not be placed now." +
                    "Please try again later.");
        }
    }

    public void orderDelivered(Integer orderNumber) {
        OrderIdView orderId = getOrderId(orderNumber);
        Order order = orderRepsitory.findById(orderId.getId()).get();

        DeliveryStatus status = order.getStatus();
        if(!status.equals(DeliveryStatus.DISPATCHED))
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Order "+orderNumber+" is not dispatched yet.");

        order.setStatus(DeliveryStatus.DELIVERED);
        orderRepsitory.save(order);
    }

    @Retry(name = ORDER_SERVICE, fallbackMethod = "updateFoodItemQuantitiesFailed")
    private boolean updateFoodItemQuantities(Set<OrderDetail> orderDetails) {
        Set<PlaceOrderDTO> placeOrderSet = new HashSet<>();

        orderDetails.forEach(orderDetail -> {
            placeOrderSet.add(new PlaceOrderDTO(orderDetail.getFoodItemId(),
                    orderDetail.getQuantity()));
        });

        log.info("Total food items to update: "+placeOrderSet.size());
        boolean updateQuantityResponse = menuConsumer.updateQuantityForFoodItems(placeOrderSet);
        log.info("Total food items updated: "+updateQuantityResponse);
        return updateQuantityResponse;
    }

    private boolean updateFoodItemQuantitiesFailed(Exception ex){
        log.error("Error occurred in restaurants service while updating the food quantities.", ex);
        return false;
    }

    public void deleteOrder(Integer orderNumber){

        OrderIdView orderIdView = getOrderId(orderNumber);
        try {
                log.info("Id for order number "+orderNumber+" is "+orderIdView.getId());
                orderRepsitory.deleteById(orderIdView.getId());
                log.info("Order number "+orderNumber+" deleted");

        }catch (Exception ex){
            log.error("Some error occurred while deleting order number "+orderNumber, ex);
            throw new InternalErrorException("Sorry...! order number: "+orderNumber+" could not be deleted. Please try again later.");
        }
    }

    public OrderIdView getOrderId(Integer orderNumber){
        Optional<OrderIdView> byOrderNumber = orderRepsitory.findByOrderNumber(orderNumber);

        if(!byOrderNumber.isPresent()){
            log.info("Order number: "+orderNumber+" does not exist");
            throw new DataNotFoundException("Sorry order number "+orderNumber+" does not exist");
        }

        return byOrderNumber.get();
    }




    @Retry(name = ORDER_SERVICE, fallbackMethod = "getMenuFailed")
    public Set<MenuDTO> getMenu(Set<OrderDetail> orderDetailSet){
        Set<MenuDTO> menuWithQuantitySet = new HashSet<>();

        log.info("Total order details requested: "+orderDetailSet.size());

        orderDetailSet.forEach(orderDetail -> {
            final MenuDTO menuForAvailableQuantity = menuConsumer.getMenuForAvailableQuantity(orderDetail.getFoodItemId(),
                    orderDetail.getQuantity());
            if(menuForAvailableQuantity !=null){
                double cost = menuForAvailableQuantity.getItemPrice() * orderDetail.getQuantity();

                menuForAvailableQuantity.setCost(
                        new CostDTO(orderDetail.getQuantity(), cost
                ));

                menuWithQuantitySet.add(menuForAvailableQuantity);
            }

        });

        log.info("Total order details available: "+menuWithQuantitySet.size());
        return menuWithQuantitySet;
    }

    public Set<MenuDTO> getMenuFailed(Exception ex){
        log.error("Error occurred while fetching menu from restaurants service.", ex);
        return new HashSet<>();
    }



}
