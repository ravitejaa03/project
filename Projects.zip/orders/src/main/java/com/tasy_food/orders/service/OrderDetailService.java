package com.tasy_food.orders.service;

import com.tasy_food.orders.dto.PlaceOrderDTO;
import com.tasy_food.orders.dto.UpdateOrderDetailDTO;
import com.tasy_food.orders.exception.DataNotFoundException;
import com.tasy_food.orders.model.OrderDetail;
import com.tasy_food.orders.repository.OrderDetailRepository;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Service
@AllArgsConstructor
@Slf4j
public class OrderDetailService {

    public final OrderDetailRepository orderDetailRepository;

    public Set<OrderDetail> saveOrderDetails(List<PlaceOrderDTO> orderList){

        Set<OrderDetail> savedOrderDetails = new HashSet<>();

        orderList.forEach(placeOrder -> {
            OrderDetail orderDetail = new OrderDetail();
            orderDetail.setFoodItemId(placeOrder.getFoodItemId());
            orderDetail.setQuantity(placeOrder.getQuantity());
            log.info("Saving order details: "+orderDetail);
            orderDetailRepository.save(orderDetail);
            savedOrderDetails.add(orderDetail);
            log.info("Saved order details: "+orderDetail.toString());
        });


            return savedOrderDetails;
    }

    @Transactional
    public void updateOrderDetails(UpdateOrderDetailDTO updateOrderDetail) {

        orderDetailRepository.findById(updateOrderDetail.id)
                .ifPresentOrElse(orderDetail -> {
                    log.info("Order details exist by id: "+orderDetail.getId());
                    orderDetail.setFoodItemId(updateOrderDetail.getFoodItemId());
                    orderDetail.setQuantity(updateOrderDetail.getQuantity());
                    orderDetailRepository.save(orderDetail);
                    log.info("Order details updated: "+orderDetail.toString());
                }, ()-> {
                    log.info("Orders with detail "+updateOrderDetail+" does not exist.");
                    throw new DataNotFoundException("Sorry order details does not exist.");
                });
    }


}
