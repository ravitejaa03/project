##Please open swagger url to view the API's

> Swagger URL:- http://localhost:8500/swagger-ui.html#