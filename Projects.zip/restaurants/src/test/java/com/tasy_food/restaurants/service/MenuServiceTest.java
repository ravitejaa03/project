package com.tasy_food.restaurants.service;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.any;
import static org.mockito.Mockito.atLeast;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.tasy_food.restaurants.dao.MenuView;
import com.tasy_food.restaurants.dao.QuantityView;
import com.tasy_food.restaurants.dto.UpdateFoodQuantityDTO;
import com.tasy_food.restaurants.respository.MenuRepository;
import com.tasy_food.restaurants.respository.RestaurantRepository;

import java.util.HashSet;
import java.util.Optional;

import org.junit.jupiter.api.Disabled;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

@ContextConfiguration(classes = {MenuService.class})
@ExtendWith(SpringExtension.class)
class MenuServiceTest {
    @MockBean
    private MenuRepository menuRepository;

    @Autowired
    private MenuService menuService;

    @MockBean
    private RestaurantRepository restaurantRepository;

    @Test
    void testGetMenuForAvailableQuantity() {
        when(this.menuRepository.findByMenuIdAndQuantityAvailableIsGreaterThanEqual((Integer) any(), (Integer) any()))
                .thenReturn(Optional.of(mock(MenuView.class)));
        this.menuService.getMenuForAvailableQuantity(123, 1);
        verify(this.menuRepository).findByMenuIdAndQuantityAvailableIsGreaterThanEqual((Integer) any(), (Integer) any());
    }


    @Test
    void testCheckAllInQuantity() {
        assertTrue(this.menuService.checkAllInQuantity(new HashSet<>()));
    }

    @Test
    void testCheckAllInQuantity2() {
        when(this.menuRepository.isNotInStock((Integer) any(), (Integer) any())).thenReturn(true);

        HashSet<UpdateFoodQuantityDTO> updateFoodQuantityDTOSet = new HashSet<>();
        updateFoodQuantityDTOSet.add(new UpdateFoodQuantityDTO());
        assertFalse(this.menuService.checkAllInQuantity(updateFoodQuantityDTOSet));
        verify(this.menuRepository).isNotInStock((Integer) any(), (Integer) any());
    }


    @Test
    void testUpdateFoodQuantities() {
        assertTrue(this.menuService.updateFoodQuantities(new HashSet<>()));
    }


    @Test
    void testUpdateFoodQuantities2() {
        QuantityView quantityView = mock(QuantityView.class);
        when(quantityView.getQuantityAvailable()).thenReturn(1);
        Optional<QuantityView> ofResult = Optional.of(quantityView);
        when(this.menuRepository.getQuantity((Integer) any())).thenReturn(ofResult);

        HashSet<UpdateFoodQuantityDTO> updateFoodQuantityDTOSet = new HashSet<>();
        updateFoodQuantityDTOSet.add(new UpdateFoodQuantityDTO());
        assertFalse(this.menuService.updateFoodQuantities(updateFoodQuantityDTOSet));
        verify(this.menuRepository).getQuantity((Integer) any());
        verify(quantityView).getQuantityAvailable();
    }

    @Test
    void testUpdateFoodQuantities3() {
        when(this.menuRepository.getQuantity((Integer) any())).thenReturn(Optional.empty());

        HashSet<UpdateFoodQuantityDTO> updateFoodQuantityDTOSet = new HashSet<>();
        updateFoodQuantityDTOSet.add(new UpdateFoodQuantityDTO());
        assertTrue(this.menuService.updateFoodQuantities(updateFoodQuantityDTOSet));
        verify(this.menuRepository).getQuantity((Integer) any());
    }


}

