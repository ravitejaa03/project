package com.tasy_food.restaurants;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestaurantsApplicationTests {

	@Test
	void contextLoads() {
	}

}
