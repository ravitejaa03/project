package com.tasy_food.restaurants.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.tasy_food.restaurants.model.Menu;
import com.tasy_food.restaurants.model.Restaurant;
import com.tasy_food.restaurants.respository.RestaurantRepository;
import com.tasy_food.restaurants.specification_builder.RestaurantSpecification;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Disabled;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.web.server.ResponseStatusException;

@ContextConfiguration(classes = {RestaurantService.class})
@ExtendWith(SpringExtension.class)
class RestaurantServiceTest {
    @MockBean
    private RestaurantRepository restaurantRepository;

    @Autowired
    private RestaurantService restaurantService;


    @Test
    void testSearchRestaurants() {
        when(this.restaurantRepository.findAll((org.springframework.data.jpa.domain.Specification<Restaurant>) any(),
                (org.springframework.data.domain.Sort) any())).thenReturn(new ArrayList<>());
        assertTrue(this.restaurantService.searchRestaurants(new RestaurantSpecification()).isEmpty());
        verify(this.restaurantRepository).findAll((org.springframework.data.jpa.domain.Specification<Restaurant>) any(),
                (org.springframework.data.domain.Sort) any());
    }


    @Test
    void testSearchRestaurants2() {
        Restaurant restaurant = new Restaurant();
        restaurant.setApproxForEach(10.0d);
        restaurant.setCuisine("Italian");
        restaurant.setId(1);
        restaurant.setLocation("Pune");
        restaurant.setMenus(new ArrayList<>());
        restaurant.setName("Small Italy");
        restaurant.setType("Non-Vew");

        ArrayList<Restaurant> restaurantList = new ArrayList<>();
        restaurantList.add(restaurant);
        when(this.restaurantRepository.findAll((org.springframework.data.jpa.domain.Specification<Restaurant>) any(),
                (org.springframework.data.domain.Sort) any())).thenReturn(restaurantList);
        assertEquals(1, this.restaurantService.searchRestaurants(new RestaurantSpecification()).size());
        verify(this.restaurantRepository).findAll((org.springframework.data.jpa.domain.Specification<Restaurant>) any(),
                (org.springframework.data.domain.Sort) any());
    }

    @Test
    void testSearchRestaurants3() {
        when(this.restaurantRepository.findAll((org.springframework.data.jpa.domain.Specification<Restaurant>) any(),
                (org.springframework.data.domain.Sort) any())).thenThrow(new ResponseStatusException(HttpStatus.CONTINUE));
        assertThrows(ResponseStatusException.class,
                () -> this.restaurantService.searchRestaurants(new RestaurantSpecification()));
        verify(this.restaurantRepository).findAll((org.springframework.data.jpa.domain.Specification<Restaurant>) any(),
                (org.springframework.data.domain.Sort) any());
    }


    @Test
    void testSearchRestaurants4() {
        Restaurant restaurant = new Restaurant();
        restaurant.setApproxForEach(10.0d);
        restaurant.setCuisine("Italian");
        restaurant.setId(1);
        restaurant.setLocation("Pune");
        restaurant.setMenus(new ArrayList<>());
        restaurant.setName("Small Italy");
        restaurant.setType("Non-Vew");

        Restaurant restaurant1 = new Restaurant();
        restaurant1.setApproxForEach(10.0d);
        restaurant1.setCuisine("Indian");
        restaurant1.setId(2);
        restaurant1.setLocation("Pune");
        restaurant1.setMenus(new ArrayList<>());
        restaurant1.setName("Kohinoor");
        restaurant1.setType("Veg");

        ArrayList<Restaurant> restaurantList = new ArrayList<>();
        restaurantList.add(restaurant1);
        restaurantList.add(restaurant);
        when(this.restaurantRepository.findAll((org.springframework.data.jpa.domain.Specification<Restaurant>) any(),
                (org.springframework.data.domain.Sort) any())).thenReturn(restaurantList);
        assertEquals(2, this.restaurantService.searchRestaurants(new RestaurantSpecification()).size());
        verify(this.restaurantRepository).findAll((org.springframework.data.jpa.domain.Specification<Restaurant>) any(),
                (org.springframework.data.domain.Sort) any());
    }


    @Test
    void testGetMenu() {
        when(this.restaurantRepository.findMenuById((Integer) any())).thenReturn(Optional.of(new ArrayList<>()));
        assertThrows(ResponseStatusException.class, () -> this.restaurantService.getMenu(123));
        verify(this.restaurantRepository).findMenuById((Integer) any());
    }

    @Test
    void testGetMenu2() {
        Menu menu = new Menu();
        menu.setItemDescription("Loaded with 3 cheese.");
        menu.setItemName("Crazy Cheese Pizza.");
        menu.setItemPrice(750.0d);
        menu.setMenuId(123);
        menu.setQuantityAvailable(1);

        ArrayList<Menu> menuList = new ArrayList<>();
        menuList.add(menu);
        Optional<List<Menu>> ofResult = Optional.of(menuList);
        when(this.restaurantRepository.findMenuById((Integer) any())).thenReturn(ofResult);
        List<Menu> actualMenu = this.restaurantService.getMenu(123);
        assertSame(menuList, actualMenu);
        assertEquals(1, actualMenu.size());
        verify(this.restaurantRepository).findMenuById((Integer) any());
    }


    @Test
    void testGetMenu3() {
        when(this.restaurantRepository.findMenuById((Integer) any()))
                .thenThrow(new ResponseStatusException(HttpStatus.CONTINUE));
        assertThrows(ResponseStatusException.class, () -> this.restaurantService.getMenu(123));
        verify(this.restaurantRepository).findMenuById((Integer) any());
    }
}

