package com.tasy_food.restaurants.dao;

public interface QuantityView {
    Integer getQuantityAvailable();
}
