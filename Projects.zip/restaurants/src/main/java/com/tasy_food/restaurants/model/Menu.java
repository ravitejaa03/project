package com.tasy_food.restaurants.model;

import lombok.Getter;
import lombok.Setter;
import org.hibernate.Hibernate;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Getter
@Setter
@Table(name = "menus")
public class Menu {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Integer menuId;
    private String itemName;
    private String itemDescription;
    @Column(columnDefinition = "float unsigned not null")
    private double itemPrice;
    @Column(columnDefinition = "int unsigned not null")
    private Integer quantityAvailable;

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || Hibernate.getClass(this) != Hibernate.getClass(o)) return false;
        Menu menu = (Menu) o;
        return menuId != null && Objects.equals(menuId, menu.menuId);
    }

    @Override
    public int hashCode() {
        return getClass().hashCode();
    }
}
