package com.tasy_food.restaurants.controller;

import com.tasy_food.restaurants.dao.MenuView;
import com.tasy_food.restaurants.dto.UpdateFoodQuantityDTO;
import com.tasy_food.restaurants.service.MenuService;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.Set;

@AllArgsConstructor
@Slf4j
@RestController
@RequestMapping("/api/v1/menu")
public class MenuController {

    private final MenuService menuService;


    @GetMapping("/available")
    public ResponseEntity<MenuView> getMenuForAvailableQuantity(@RequestParam("id") Integer foodItemId,
                                                                     @RequestParam("req") Integer quantity){
        log.info("Request for food item  "+ foodItemId+ " with quantity "+quantity);
        MenuView foodItem = menuService.getMenuForAvailableQuantity(foodItemId, quantity);
        log.info("Retrieved menu for id "+foodItem+": "+foodItem);
        return ResponseEntity.status(HttpStatus.OK).body(foodItem);
    }

    @PutMapping("/quantities")
    public ResponseEntity<Boolean> updateFoodItemQuantities(@RequestBody @Validated Set<UpdateFoodQuantityDTO> foodItemList){

        log.info("Request to update food quantities in bulk of size: "+foodItemList.size());
        boolean status = false;
        if(menuService.checkAllInQuantity(foodItemList))
            status = menuService.updateFoodQuantities(foodItemList);
        log.info("Food quantities updated: "+status);

        return ResponseEntity.status(status ? HttpStatus.OK: HttpStatus.INTERNAL_SERVER_ERROR).body(status);

    }
}
