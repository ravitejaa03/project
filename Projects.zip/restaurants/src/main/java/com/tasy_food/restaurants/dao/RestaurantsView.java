package com.tasy_food.restaurants.dao;

public interface RestaurantsView {

    Integer getId();
    String getName();
    String getLocation();
    String getCuisine();
    String getType();
    double getApproxForEach();
}
