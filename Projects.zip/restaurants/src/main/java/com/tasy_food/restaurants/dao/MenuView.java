package com.tasy_food.restaurants.dao;

public interface MenuView {
    Integer getMenuId();
    String getItemName();
    String getItemDescription();
    double getItemPrice();
}
