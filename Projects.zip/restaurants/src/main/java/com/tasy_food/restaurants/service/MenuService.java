package com.tasy_food.restaurants.service;

import com.tasy_food.restaurants.dao.MenuView;
import com.tasy_food.restaurants.dao.QuantityView;
import com.tasy_food.restaurants.dto.*;
import com.tasy_food.restaurants.respository.MenuRepository;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;

@Service
@AllArgsConstructor
@Slf4j
public class MenuService {

    private final MenuRepository menuRepository;


    public MenuView getMenuForAvailableQuantity(Integer foodItemId, Integer quantity) {
        Optional<MenuView> menu = menuRepository.findByMenuIdAndQuantityAvailableIsGreaterThanEqual(foodItemId, quantity);
        return menu.orElse(null);
    }

    public boolean checkAllInQuantity(Set<UpdateFoodQuantityDTO> foodItemList){
        Optional<UpdateFoodQuantityDTO> first = foodItemList.
                stream().
                filter(foodItem -> menuRepository.isNotInStock(foodItem.getQuantity(), foodItem.getFoodItemId()))
                .findFirst();

        return !first.isPresent();
    }

    @Transactional
    public boolean updateFoodQuantities(Set<UpdateFoodQuantityDTO> foodItemList) {

        try {
            foodItemList.forEach(foodItem -> {
                Optional<QuantityView> quantity = menuRepository.getQuantity(foodItem.getFoodItemId());
                if(quantity.isPresent()){
                    int quantityToUpdate = quantity.get().getQuantityAvailable() - foodItem.getQuantity();
                    menuRepository.updateQuantityAvailableByMenuId(quantityToUpdate,
                            foodItem.getFoodItemId());
                    log.info("Updated quantity to: "+quantityToUpdate+" for food item: "+foodItem.getFoodItemId());
                }

            });
            return true;
        }catch (Exception ex){
            log.error("Some error occurred while updating the quantities.", ex);
        }

        return false;
    }
}
