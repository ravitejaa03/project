package com.tasy_food.restaurants.dto;

import com.tasy_food.restaurants.dao.MenuView;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class OrderDTO {

//   private Integer menuId;
//   private String itemName;
//   private String itemDescription;
//   private double itemPrice;
   private MenuView menuView;
   private Integer reqStock = 0;
   private double totalAmount = 0;
}
