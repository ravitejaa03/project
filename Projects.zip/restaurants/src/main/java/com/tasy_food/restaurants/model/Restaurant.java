package com.tasy_food.restaurants.model;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.hibernate.Hibernate;

import javax.persistence.*;
import javax.validation.constraints.DecimalMin;
import javax.validation.constraints.NotEmpty;
import java.util.Collection;
import java.util.List;
import java.util.Objects;

@Entity
@Getter
@Setter
@Table(name = "restaurants")
@ToString
public class Restaurant {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Integer id;
    @NotEmpty(message = "Restaurant name cannot be empty")
    @Column(nullable = false)
    private String name;
    @NotEmpty(message = "Location cannot be empty")
    @Column(nullable = false)
    private String location;
    @NotEmpty(message = "Cuisine cannot be empty")
    @Column(nullable = false)
    private String cuisine;
    private String type;
    @DecimalMin(message = "Approx for each value should be not less than 0.00", value = "0.00")
    @Column(nullable = false, columnDefinition = "Decimal(10,2) default '100.00'")
    private double approxForEach;


    @OneToMany(fetch = FetchType.LAZY)
    @JoinTable(name = "restaurant_menu_mapping", joinColumns= @JoinColumn(name = "restaurant_id")
               , inverseJoinColumns = @JoinColumn(name = "menu_id")
    )
    private List<Menu> menus;

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || Hibernate.getClass(this) != Hibernate.getClass(o)) return false;
        Restaurant that = (Restaurant) o;
        return id != null && Objects.equals(id, that.id);
    }

    @Override
    public int hashCode() {
        return getClass().hashCode();
    }
}
