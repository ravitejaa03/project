package com.tasy_food.restaurants.specification_builder;

import com.tasy_food.restaurants.model.Restaurant;
import org.springframework.data.jpa.domain.Specification;

import java.util.ArrayList;
import java.util.List;

public class RestaurantSpecificationsBuilder {

    private List<SearchCriteria> params = new ArrayList<SearchCriteria>();

    public RestaurantSpecificationsBuilder with(
            String key, String operation, Object value, String prefix, String suffix) {

        SearchOperation op = SearchOperation.getSimpleOperation(operation.charAt(0));
        if (op != null) {
            if (op == SearchOperation.EQUALITY) {
                boolean startWithAsterisk = prefix.contains("*");
                boolean endWithAsterisk = suffix.contains("*");

                if (startWithAsterisk && endWithAsterisk) {
                    op = SearchOperation.CONTAINS;
                } else if (startWithAsterisk) {
                    op = SearchOperation.ENDS_WITH;
                } else if (endWithAsterisk) {
                    op = SearchOperation.STARTS_WITH;
                }
            }
            SearchCriteria searchCriteria = new SearchCriteria();
            searchCriteria.setKey(key);
            searchCriteria.setOperation(op);
            searchCriteria.setValue(value);
            params.add(searchCriteria);
        }
        return this;
    }

    public Specification<Restaurant> build() {
        if (params.size() == 0) {
            return null;
        }

        Specification result = new RestaurantSpecification(params.get(0));
        System.out.println(params.get(0));
        for (int i = 1; i < params.size(); i++) {

            result = Specification.where(result).and(new RestaurantSpecification(params.get(i)));
        }

        return result;
    }
}
