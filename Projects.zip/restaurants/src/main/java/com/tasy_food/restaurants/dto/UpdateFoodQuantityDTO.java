package com.tasy_food.restaurants.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class UpdateFoodQuantityDTO {

    @NotEmpty(message = "Food item Id cannot be null.")
    @Min(value = 0, message = "Food Item id cannot be less than zero.")
    public Integer foodItemId;
    @NotEmpty(message = "Quantity cannot be null.")
    @Min(value = 0, message = "Quantity cannot be less than zero.")
    public Integer quantity;
}
