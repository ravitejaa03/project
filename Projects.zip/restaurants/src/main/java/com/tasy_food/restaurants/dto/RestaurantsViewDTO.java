package com.tasy_food.restaurants.dto;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class RestaurantsViewDTO {


    private Integer id;
    private String name;
    private String location;
    private String cuisine;
    private String type;
    private double approxForEach;
}
