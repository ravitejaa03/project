package com.tasy_food.restaurants.service;

import com.tasy_food.restaurants.dto.RestaurantsViewDTO;
import com.tasy_food.restaurants.model.Menu;
import com.tasy_food.restaurants.model.Restaurant;
import com.tasy_food.restaurants.respository.RestaurantRepository;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
@AllArgsConstructor
@Slf4j
public class RestaurantService {

    private final RestaurantRepository restaurantRepository;

    public List<RestaurantsViewDTO> searchRestaurants(Specification<Restaurant> spec){
        List<Restaurant> restaurantsList = restaurantRepository.findAll(Specification.where(spec), Sort.by("id").ascending());
        List<RestaurantsViewDTO> restaurantsViewList = new ArrayList<>();

        restaurantsList.forEach(restaurant -> {
            restaurantsViewList.add(
                    new RestaurantsViewDTO(restaurant.getId(),
                            restaurant.getName(),
                            restaurant.getLocation(),
                            restaurant.getCuisine(),
                            restaurant.getType(),
                            restaurant.getApproxForEach())
            );
        });

        return restaurantsViewList;
    }


    public List<Menu> getMenu(Integer restaurantId) {
        Optional<List<Menu>> menuList = restaurantRepository.findMenuById(restaurantId);
        if(menuList.get().size() > 0)
            return menuList.get();
        else
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Restaurant does not exist.");
    }
}
