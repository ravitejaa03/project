package com.tasy_food.restaurants.controller;

import com.google.common.base.Joiner;
import com.tasy_food.restaurants.dto.*;
import com.tasy_food.restaurants.model.Menu;
import com.tasy_food.restaurants.model.Restaurant;
import com.tasy_food.restaurants.service.MenuService;
import com.tasy_food.restaurants.service.RestaurantService;
import com.tasy_food.restaurants.specification_builder.RestaurantSpecificationsBuilder;
import com.tasy_food.restaurants.specification_builder.SearchOperation;
import io.swagger.annotations.ApiOperation;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.dao.InvalidDataAccessApiUsageException;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@RestController
@RequestMapping("/api/v1/restaurant")
@AllArgsConstructor
@Slf4j
public class RestaurantController {

    private final RestaurantService restaurantService;

    @GetMapping("/search")
    @ApiOperation(value = "\n Returns list of restaurants based on the attributes" +
            " passed in search Comparators used are :- case ':' return EQUALITY; case '!': " +
            "return NEGATION; case '>': return GREATER_THAN; case '<': return LESS_THAN; case '~': " +
            "return LIKE. Eg:http://localhost:8500/api/v1/restaurant/search?query=cuisine:Con* " +
            "return restaurants cuisine starting from Con")
    public ResponseEntity<List<RestaurantsViewDTO>> searchProduct(@RequestParam("query") String query){
        log.info("Request to search restaurants: "+query);
        List<RestaurantsViewDTO> restaurantsList = new ArrayList<>();
        try {
            RestaurantSpecificationsBuilder builder = new RestaurantSpecificationsBuilder();

            String operationSetExper = Joiner.on("|").join(SearchOperation.SIMPLE_OPERATION_SET);

            Pattern pattern = Pattern.compile(
                    "(\\w+?)(" + operationSetExper + ")(\\p{Punct}?)(\\w+?)(\\p{Punct}?),");
            Matcher matcher = pattern.matcher(query + ",");

            while (matcher.find()) {
                builder.with(
                        matcher.group(1),
                        matcher.group(2),
                        matcher.group(4),
                        matcher.group(3),
                        matcher.group(5));
            }

            Specification<Restaurant> spec = builder.build();
            restaurantsList = restaurantService.searchRestaurants(spec);
        }catch (InvalidDataAccessApiUsageException invalidDataAccessApiUsageException){
            log.error("Error occurred while searching restaurants: "+query, invalidDataAccessApiUsageException);
            throw new InvalidDataAccessApiUsageException("Invalid parameters passed while searching for restaurants." +
                    "Please pass valid parameters.");
        } catch (Exception ex){
            log.error("Error occurred while searching restaurants: "+query, ex);
            throw new ResponseStatusException(HttpStatus.NOT_FOUND,"Some error occurred while searching for products.");

        }

        log.info("Total restaurants retrieved: "+restaurantsList.size());
        return ResponseEntity.ok(restaurantsList);


    }

    @GetMapping("/{id}/menu")
    public ResponseEntity<List<Menu>> getMenu(@PathVariable("id") Integer restaurantId){
        log.info("Request to retrieve menus for restaurant id: "+restaurantId);
        List<Menu> menu = restaurantService.getMenu(restaurantId);
        log.info("Total menus retrieved "+menu.size()+" for restaurant id: "+restaurantId);
        return ResponseEntity.ok(menu);
    }




}
