package com.tasy_food.restaurants.respository;

import com.tasy_food.restaurants.dao.MenuView;
import com.tasy_food.restaurants.model.Menu;
import com.tasy_food.restaurants.model.Restaurant;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;


@Repository
public interface RestaurantRepository extends JpaRepository<Restaurant, Integer>, JpaSpecificationExecutor<Restaurant> {

    @Query("select r.menus from Restaurant r where r.id = :restaurantId ")
    Optional<List<Menu>> findMenuById(@Param("restaurantId") Integer restaurantId);
}
