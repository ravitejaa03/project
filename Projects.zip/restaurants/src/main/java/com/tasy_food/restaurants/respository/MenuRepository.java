package com.tasy_food.restaurants.respository;

import com.tasy_food.restaurants.dao.MenuView;
import com.tasy_food.restaurants.dao.QuantityView;
import com.tasy_food.restaurants.model.Menu;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.Optional;

@Repository
public interface MenuRepository extends JpaRepository<Menu, Integer> {

    @Query("select (m.quantityAvailable < :quantityRequired ) from Menu m where m.menuId = :menuId ")
    boolean isNotInStock(@Param("quantityRequired") Integer quantityRequired, @Param("menuId") Integer menuId);


    @Query("select m from Menu m where m.menuId = :menuId and m.quantityAvailable >= :quantityRequired ")
    Optional<MenuView> findByMenuIdAndQuantityAvailableIsGreaterThanEqual(@Param("menuId") Integer menuId,
                                                                                      @Param("quantityRequired") Integer quantityRequired);

    @Transactional
    @Modifying
    @Query("update Menu m set m.quantityAvailable = :quantityAvailable where m.menuId = :menuId")
    void updateQuantityAvailableByMenuId(@Param("quantityAvailable") Integer quantityAvailable, @Param("menuId") Integer menuId);

    @Query("select m from Menu m where m.menuId = :menuId")
    Optional<QuantityView> getQuantity(@Param("menuId") Integer menuId);



//    MenuIdNameQuantityOnly findByMenuId(Long menuId);


}
