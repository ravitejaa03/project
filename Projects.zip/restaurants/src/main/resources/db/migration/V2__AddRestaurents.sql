INSERT INTO restaurants (id, name, location, cuisine, approx_for_each, type)
VALUES (1, 'Taj Hotel', 'Pune', 'Continental', 800.00, 'Non-Veg'),
 (2, 'The Irani Cafe','Pune','Parsi', 500.00, 'Non-Veg'),
 (3, 'Vaishali','Pune','South Indian', 300.00, 'Veg'),
 (4, 'Supriya','Pune','Indian', 400.00, 'Veg')