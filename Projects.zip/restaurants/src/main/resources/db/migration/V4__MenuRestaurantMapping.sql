INSERT INTO restaurant_menu_mapping (menu_id, restaurant_id)
VALUES (1, 1),
(2,1),
(3,1),
(4,2),
(5,2),
(6,2),
(7,3),
(8,3),
(9,4),
(10,4)