INSERT INTO menus (menu_id, item_name, item_description, item_price, quantity_available)
VALUES (1, 'Chicken Taco', 'A flour tortilla taco wrap, stuffed with crispy chicken and shredded cheese.', 250.00, 60),
(2, 'Chicken Cordon Bleu Sizzler', 'Chicken stuffed with cheese n crumb fried served with mash potatoes n mushroom.', 600.00, 100),
(3, 'Vegetables & Fetta Pizza', 'Marinara sauce-fresh mozzarella-onion-bell peppers-corn-olives-spinach-sun dried', 550.00, 250),
(4, 'Bun Maska', '', 50.00, 150),
(5, 'Chicken Dum Biryani', '1kg contains 6 pcs fresh chicken are marinated in a mixture of freshly ground BBK spices & layered with long grain basmati rice in the handi and slow cooked in the sealed handi.', 260, 200),
(6, 'Blueberry Cheese Cake', '', 270.0, 20),
(7, 'Masala Dosa', 'Made from rice, lentils, potato, fenugreek, ghee and curry leaves, and served with chutneys and sambar.', 120.0, 20),
(8, 'Idli Sambar', '2 idlis served with sambar and chutney.',90, 50),
(9, 'Paneer Butter Masala', '', 140, 90),
(10, "Veg Kolhapuri", '', 190, 60)